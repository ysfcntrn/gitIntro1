package Utils;

public interface BrowserUtils {

}
